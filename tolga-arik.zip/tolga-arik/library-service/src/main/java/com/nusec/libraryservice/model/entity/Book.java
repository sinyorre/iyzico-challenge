package com.nusec.libraryservice.model.entity;

import lombok.AllArgsConstructor;
import lombok.Data;

import javax.persistence.Entity;

@Entity
@AllArgsConstructor
@Data
public class Book extends BaseEntity {

}
