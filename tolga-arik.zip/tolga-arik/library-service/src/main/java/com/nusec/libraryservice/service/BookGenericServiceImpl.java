package com.nusec.libraryservice.service;

import com.nusec.libraryservice.exceptions.BookNotFoundException;
import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.entity.Book;
import com.nusec.libraryservice.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("bookService")
public class BookGenericServiceImpl implements IGenericService<Book> {

    @Autowired
    BookRepository bookRepository;

    @Override
    public Book save(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public PagingResponse<Book> findAll(Integer page) {
        PageRequest pageRequest = PageRequest.of(--page, 10, Sort.by("id").descending());
        Page<Book> bookPage = bookRepository.findAll(pageRequest);
        return new PagingResponse<>(bookPage.getContent(),
                bookPage.getTotalElements(),
                bookPage.getTotalPages()
        );
    }

    @Override
    public Book findById(Long id) {
        Optional<Book> optionalAdvert = bookRepository.findById(id);
        if (optionalAdvert.isPresent()) {
            return optionalAdvert.get();
        }

        throw new BookNotFoundException("Book Not Found");
    }

    @Override
    public Book update(Book entity, Long id) {
        boolean isExist = bookRepository.existsById(id);
        if (isExist) return bookRepository.save(entity);
        throw new BookNotFoundException("Book Not Found");

    }

    @Override
    public Book changeStatus(Long id) {
        Book book = findById(id);
        book.setAvailable(!book.isAvailable());

        return bookRepository.save(book);
    }

    @Override
    public void delete(Long id) {
        bookRepository.deleteById(id);
    }


    @Override
    public Long countByAvailable(boolean available) {
        return bookRepository.countBooksByAvailable(available);
    }

    @Override
    public Long count() {
        return bookRepository.count();
    }

    @Override
    public Boolean getAvailableStatusByName(String name) {
        return bookRepository.findByName(name).isAvailable();
    }

}
