package com.nusec.libraryservice.controller;


import com.nusec.libraryservice.manager.NewspaperManager;
import com.nusec.libraryservice.model.StatusResponse;
import com.nusec.libraryservice.model.dto.NewspaperDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/newspapers")
public class NewspaperController {

    @Autowired
    NewspaperManager newspaperManager;

    @GetMapping
    public ResponseEntity<PagingResponseDTO<NewspaperDTO>> getAllNewspapers(@RequestParam Integer page) {
        return new ResponseEntity<>(newspaperManager.getNewspaperList(page), HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<NewspaperDTO> getNewspaper(@PathVariable Long id) {
        return new ResponseEntity<>(newspaperManager.getNewspaper(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<NewspaperDTO> saveNewspaper(@Valid @RequestBody NewspaperDTO newspaper) {
        return new ResponseEntity<>(newspaperManager.saveNewspaper(newspaper), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<NewspaperDTO> updateNewspaper(@Valid @RequestBody NewspaperDTO newspaper, @PathVariable Long id) {
        return new ResponseEntity<>(newspaperManager.updateNewspaper(id, newspaper), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Boolean> deleteNewspaper(@PathVariable Long id) {
        newspaperManager.deleteNewspaper(id);
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

    @PutMapping("{id}/status")
    public ResponseEntity<NewspaperDTO> changeStatus(@PathVariable Long id) {
        return new ResponseEntity<>(newspaperManager.changeStatus(id), HttpStatus.OK);
    }

    @GetMapping("{name}/status")
    public ResponseEntity<StatusResponse> getAvailableStatusByName(@PathVariable String name) {
        Boolean statusByName = newspaperManager.getAvailableStatusByName(name);

        StatusResponse response = StatusResponse.builder()
                .status(statusByName)
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
