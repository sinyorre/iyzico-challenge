package com.nusec.libraryservice.controller;


import com.nusec.libraryservice.manager.DocumentaryManager;
import com.nusec.libraryservice.model.StatusResponse;
import com.nusec.libraryservice.model.dto.DocumentaryDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/documentaries")
public class DocumentaryController {

    @Autowired
    DocumentaryManager documentaryManager;

    @GetMapping
    public ResponseEntity<PagingResponseDTO<DocumentaryDTO>> getAllDocumentaries(@RequestParam Integer page) {
        return new ResponseEntity<>(documentaryManager.getDocumentaryList(page), HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<DocumentaryDTO> getDocumentary(@PathVariable Long id) {
        return new ResponseEntity<>(documentaryManager.getDocumentary(id), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<DocumentaryDTO> saveDocumentaryDTO(@Valid @RequestBody DocumentaryDTO documentaryDTO) {
        return new ResponseEntity<>(documentaryManager.saveDocumentary(documentaryDTO), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<DocumentaryDTO> updateDocumentary(@Valid @RequestBody DocumentaryDTO documentary, @PathVariable Long id) {
        return new ResponseEntity<>(documentaryManager.updateDocumentary(id, documentary), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Boolean> deleteDocumentary(@PathVariable Long id) {
        documentaryManager.deleteDocumentary(id);
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

    @PutMapping("{id}/status")
    public ResponseEntity<DocumentaryDTO> changeStatus(@PathVariable Long id) {
        return new ResponseEntity<>(documentaryManager.changeStatus(id), HttpStatus.OK);
    }

    @GetMapping("{name}/status")
    public ResponseEntity<StatusResponse> getAvailableStatusByName(@PathVariable String name) {
        Boolean statusByName = documentaryManager.getAvailableStatusByName(name);

        StatusResponse response = StatusResponse.builder()
                .status(statusByName)
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
