package com.nusec.libraryservice.model.dto;

import lombok.Data;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

@Data
public class NewspaperDTO extends BaseDTO {

    @Id
    @GeneratedValue
    private Long id;

    private boolean available;

    private String name;

}
