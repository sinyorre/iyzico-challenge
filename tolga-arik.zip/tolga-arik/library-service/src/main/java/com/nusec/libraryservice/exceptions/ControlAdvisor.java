package com.nusec.libraryservice.exceptions;


import com.nusec.libraryservice.model.ErrorResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import javax.servlet.http.HttpServletRequest;
import java.time.ZoneId;
import java.time.ZonedDateTime;

@ControllerAdvice
public class ControlAdvisor extends ResponseEntityExceptionHandler {

    @ExceptionHandler
    public ResponseEntity<ErrorResponse> handleAccessDeniedException(AccessDeniedException e, HttpServletRequest request) {
        return ResponseEntity.status(403).body(new ErrorResponse(e.getMessage()));
    }

    @ExceptionHandler(value = Exception.class)
    public ResponseEntity<Object> handleException(Exception exception) {
        HttpStatus badRequest = HttpStatus.BAD_REQUEST;

        return getApiException(badRequest, exception.getMessage());
    }


    @ExceptionHandler(value = ItemNameNotFoundException.class)
    public ResponseEntity<Object> handleItemNameNotFoundException(ItemNameNotFoundException exception) {
        HttpStatus badRequest = HttpStatus.BAD_REQUEST;

        return getApiException(badRequest, exception.getMessage());
    }

    @ExceptionHandler(value = BookNotFoundException.class)
    public ResponseEntity<Object> handleBookNotFoundException(BookNotFoundException exception) {
        HttpStatus badRequest = HttpStatus.BAD_REQUEST;

        return getApiException(badRequest, exception.getMessage());
    }

    @ExceptionHandler(value = DocumentaryNotFoundException.class)
    public ResponseEntity<Object> handleDocumentaryNotFoundException(DocumentaryNotFoundException exception) {
        HttpStatus badRequest = HttpStatus.BAD_REQUEST;

        return getApiException(badRequest, exception.getMessage());
    }

    @ExceptionHandler(value = NewspaperNotFoundException.class)
    public ResponseEntity<Object> handleNewspaperNotFoundException(NewspaperNotFoundException exception) {
        HttpStatus badRequest = HttpStatus.BAD_REQUEST;

        return getApiException(badRequest, exception.getMessage());
    }

    private ResponseEntity<Object> getApiException(HttpStatus badRequest, String message) {
        ApiException apiException = new ApiException(
                message,
                badRequest,
                ZonedDateTime.now(ZoneId.of("Z"))
        );

        return new ResponseEntity<>(apiException, badRequest);
    }


}