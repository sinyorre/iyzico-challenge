package com.nusec.libraryservice.model.dto;

import lombok.Data;

@Data
public class DocumentaryDTO extends BaseDTO {


}
