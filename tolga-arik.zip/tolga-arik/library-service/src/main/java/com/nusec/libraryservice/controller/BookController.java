package com.nusec.libraryservice.controller;


import com.nusec.libraryservice.manager.BookManager;
import com.nusec.libraryservice.model.StatusResponse;
import com.nusec.libraryservice.model.dto.BookDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    BookManager bookManager;

    @GetMapping
    public ResponseEntity<PagingResponseDTO<BookDTO>> getAllBooks(@RequestParam Integer page) {
        return new ResponseEntity<>(bookManager.getBookList(page), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<BookDTO> saveBook(@Valid @RequestBody BookDTO bookDTO) {
        return new ResponseEntity<>(bookManager.saveBook(bookDTO), HttpStatus.OK);
    }

    @GetMapping("{id}")
    public ResponseEntity<BookDTO> getBook(@PathVariable Long id) {
        return new ResponseEntity<>(bookManager.getBook(id), HttpStatus.OK);
    }

    @PutMapping("{id}")
    public ResponseEntity<BookDTO> updateBook(@Valid @RequestBody BookDTO bookDTO, @PathVariable Long id) {
        return new ResponseEntity<>(bookManager.updateBook(id, bookDTO), HttpStatus.OK);
    }

    @DeleteMapping("{id}")
    public ResponseEntity<Boolean> deleteBook(@PathVariable Long id) {
        bookManager.deleteBook(id);
        return new ResponseEntity<>(true, HttpStatus.OK);
    }

    @PutMapping("{id}/status")
    public ResponseEntity<BookDTO> changeStatus(@PathVariable Long id) {
        return new ResponseEntity<>(bookManager.changeStatus(id), HttpStatus.OK);
    }

    @GetMapping("{name}/status")
    public ResponseEntity<StatusResponse> getAvailableStatusByName(@PathVariable String name) {
        Boolean statusByName = bookManager.getAvailableStatusByName(name);

        StatusResponse response = StatusResponse.builder()
                .status(statusByName)
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }

}
