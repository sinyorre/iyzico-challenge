package com.nusec.libraryservice.controller;


import com.nusec.libraryservice.adapter.ServiceAdapter;
import com.nusec.libraryservice.model.CountResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.lang.Nullable;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/items")
public class ItemController {

    @Autowired
    ServiceAdapter serviceAdapter;

    @GetMapping
    public ResponseEntity<CountResponse> countByParams(@Nullable @RequestParam String type, @Nullable @RequestParam Boolean available) {
        Long totalCount = 0L;
        if (type == null) {
            totalCount = serviceAdapter.count();
            return getCountResponse(totalCount);
        }
        totalCount = serviceAdapter.countByParams(type, available);
        return getCountResponse(totalCount);
    }


    private ResponseEntity<CountResponse> getCountResponse(Long totalCount) {
        CountResponse response = CountResponse.builder()
                .totalCount(totalCount)
                .build();
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
}
