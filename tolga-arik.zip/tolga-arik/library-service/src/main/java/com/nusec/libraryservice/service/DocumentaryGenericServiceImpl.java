package com.nusec.libraryservice.service;

import com.nusec.libraryservice.exceptions.DocumentaryNotFoundException;
import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.entity.Documentary;
import com.nusec.libraryservice.repository.DocumentaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("documentaryService")
public class DocumentaryGenericServiceImpl implements IGenericService<Documentary> {

    @Autowired
    DocumentaryRepository documentaryRepository;

    @Override
    public Documentary save(Documentary documentary) {
        return documentaryRepository.save(documentary);
    }

    @Override
    public PagingResponse<Documentary> findAll(Integer page) {
        Page<Documentary> documentaryPage = documentaryRepository.findAll(PageRequest.of(--page, 10));
        return new PagingResponse<>(documentaryPage.getContent(),
                documentaryPage.getTotalElements(),
                documentaryPage.getTotalPages()
        );
    }

    @Override
    public Documentary findById(Long id) {
        Optional<Documentary> optionalAdvert = documentaryRepository.findById(id);
        if (optionalAdvert.isPresent()) {
            return optionalAdvert.get();
        }

        throw new DocumentaryNotFoundException("Documentary Not Found");
    }


    @Override
    public void delete(Long id) {
        documentaryRepository.deleteById(id);
    }

    @Override
    public Long countByAvailable(boolean available) {
        return documentaryRepository.countDocumentariesByAvailable(available);
    }

    @Override
    public Long count() {
        return documentaryRepository.count();
    }

    @Override
    public Boolean getAvailableStatusByName(String name) {
        return documentaryRepository.findByName(name).isAvailable();
    }

    @Override
    public Documentary update(Documentary documentary, Long id) {
        boolean isExist = documentaryRepository.existsById(id);
        documentary.setId(id);
        if (isExist) return documentaryRepository.save(documentary);
        throw new DocumentaryNotFoundException("Documentary Not Found");

    }

    @Override
    public Documentary changeStatus(Long id) {
        Documentary documentary = findById(id);
        documentary.setAvailable(!documentary.isAvailable());
        return documentaryRepository.save(documentary);
    }
}
