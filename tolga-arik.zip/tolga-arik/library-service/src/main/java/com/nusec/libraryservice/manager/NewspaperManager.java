package com.nusec.libraryservice.manager;

import com.nusec.libraryservice.model.dto.NewspaperDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;

public interface NewspaperManager {

    NewspaperDTO saveNewspaper(NewspaperDTO newspaperDTO);

    NewspaperDTO updateNewspaper(Long id, NewspaperDTO newspaperDTO);

    boolean deleteNewspaper(Long id);

    NewspaperDTO getNewspaper(Long id);

    PagingResponseDTO<NewspaperDTO> getNewspaperList(Integer page);

    NewspaperDTO changeStatus(Long id);

    Boolean getAvailableStatusByName(String name);
}
