package com.nusec.libraryservice.adapter;

import com.nusec.libraryservice.exceptions.TypeNotFoundException;
import com.nusec.libraryservice.service.BookGenericServiceImpl;
import com.nusec.libraryservice.service.DocumentaryGenericServiceImpl;
import com.nusec.libraryservice.service.NewspaperGenericServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ServiceAdapter {

    private final String BOOKS = "books";
    private final String DOCUMENTARIES = "documentaries";
    private final String NEWSPAPERS = "newspapers";
    private final String TYPE_NOT_FOUND_MESSAGE = "Object Type is wrong";
    @Autowired
    private BookGenericServiceImpl bookGenericService;
    @Autowired
    private NewspaperGenericServiceImpl newspaperGenericService;
    @Autowired
    private DocumentaryGenericServiceImpl documentaryGenericService;

    public Long countByParams(String type, boolean available) {
        type = type.toLowerCase();

        switch (type) {
            case BOOKS:
                return bookGenericService.countByAvailable(available);
            case NEWSPAPERS:
                return newspaperGenericService.countByAvailable(available);
            case DOCUMENTARIES:
                return documentaryGenericService.countByAvailable(available);
            default:
                throw new TypeNotFoundException(TYPE_NOT_FOUND_MESSAGE);
        }
    }

    public Long count() {
        return bookGenericService.count() + documentaryGenericService.count() + newspaperGenericService.count();
    }
}
