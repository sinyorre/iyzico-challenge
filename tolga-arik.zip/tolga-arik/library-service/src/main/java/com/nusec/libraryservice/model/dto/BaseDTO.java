package com.nusec.libraryservice.model.dto;

import lombok.Data;

@Data
public abstract class BaseDTO {
    private boolean available;
    private String name;
}
