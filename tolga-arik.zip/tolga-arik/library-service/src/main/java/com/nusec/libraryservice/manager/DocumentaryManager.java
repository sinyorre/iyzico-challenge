package com.nusec.libraryservice.manager;

import com.nusec.libraryservice.model.dto.DocumentaryDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;

public interface DocumentaryManager {

    DocumentaryDTO saveDocumentary(DocumentaryDTO documentaryDTO);

    DocumentaryDTO updateDocumentary(Long id, DocumentaryDTO documentaryDTO);

    boolean deleteDocumentary(Long id);

    DocumentaryDTO getDocumentary(Long id);

    PagingResponseDTO<DocumentaryDTO> getDocumentaryList(Integer page);

    DocumentaryDTO changeStatus(Long id);

    Boolean getAvailableStatusByName(String name);
}
