package com.nusec.libraryservice.manager;

import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.dto.DocumentaryDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;
import com.nusec.libraryservice.model.entity.Documentary;
import com.nusec.libraryservice.service.IGenericService;
import com.nusec.libraryservice.utils.ModelMapperUtil;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class DocumentaryManagerImpl implements DocumentaryManager {

    private final ModelMapper modelMapper;

    private final IGenericService<Documentary> documentaryService;


    @Override
    public DocumentaryDTO saveDocumentary(DocumentaryDTO documentaryDTO) {
        Documentary documentary = modelMapper.map(documentaryDTO, Documentary.class);
        Documentary savedDocumentary = documentaryService.save(documentary);

        return modelMapper.map(savedDocumentary, DocumentaryDTO.class);
    }

    @Override
    public DocumentaryDTO updateDocumentary(Long id, DocumentaryDTO documentaryDTO) {
        Documentary documentary = modelMapper.map(documentaryDTO, Documentary.class);
        Documentary updatedDocumentary = documentaryService.update(documentary, id);
        return modelMapper.map(updatedDocumentary, DocumentaryDTO.class);
    }

    @Override
    public boolean deleteDocumentary(Long id) {
        documentaryService.delete(id);
        return true;
    }

    @Override
    public DocumentaryDTO getDocumentary(Long id) {
        Documentary documentary = documentaryService.findById(id);
        return modelMapper.map(documentary, DocumentaryDTO.class);
    }

    @Override
    public PagingResponseDTO<DocumentaryDTO> getDocumentaryList(Integer page) {
        PagingResponse<Documentary> documentaryPagingResponse = documentaryService.findAll(page);
        List<Documentary> documentaryList = documentaryPagingResponse.getData();
        List<DocumentaryDTO> documentaryDTOList = ModelMapperUtil.mapList(documentaryList, DocumentaryDTO.class);


        PagingResponseDTO<DocumentaryDTO> pagingResponseDTO = new PagingResponseDTO<>();
        pagingResponseDTO.setData(documentaryDTOList);
        pagingResponseDTO.setTotalElements(documentaryPagingResponse.getTotalElements());
        pagingResponseDTO.setTotalPages(documentaryPagingResponse.getTotalPages());
        return pagingResponseDTO;
    }

    @Override
    public DocumentaryDTO changeStatus(Long id) {
        Documentary documentary = documentaryService.changeStatus(id);
        return modelMapper.map(documentary, DocumentaryDTO.class);
    }

    @Override
    public Boolean getAvailableStatusByName(String name) {
        return documentaryService.getAvailableStatusByName(name);
    }

}
