package com.nusec.libraryservice.service;

import com.nusec.libraryservice.exceptions.NewspaperNotFoundException;
import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.entity.Newspaper;
import com.nusec.libraryservice.repository.NewspaperRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service("newspaperService")
public class NewspaperGenericServiceImpl implements IGenericService<Newspaper> {

    @Autowired
    NewspaperRepository newspaperRepository;

    @Override
    public Newspaper save(Newspaper newspaper) {
        return newspaperRepository.save(newspaper);
    }

    @Override
    public PagingResponse<Newspaper> findAll(Integer page) {
        Page<Newspaper> newspaperPage = newspaperRepository.findAll(PageRequest.of(--page, 10));
        return new PagingResponse<>(newspaperPage.getContent(),
                newspaperPage.getTotalElements(),
                newspaperPage.getTotalPages()
        );
    }

    @Override
    public Newspaper findById(Long id) {
        Optional<Newspaper> optionalAdvert = newspaperRepository.findById(id);
        if (optionalAdvert.isPresent()) {
            return optionalAdvert.get();
        }

        throw new NewspaperNotFoundException("Newspaper Not Found");
    }


    @Override
    public void delete(Long id) {
        newspaperRepository.deleteById(id);
    }

    @Override
    public Long countByAvailable(boolean available) {
        return newspaperRepository.countNewspapersByAvailable(available);
    }

    @Override
    public Long count() {
        return newspaperRepository.count();
    }

    @Override
    public Boolean getAvailableStatusByName(String name) {
        return newspaperRepository.findByName(name).isAvailable();
    }

    @Override
    public Newspaper update(Newspaper newspaper, Long id) {
        boolean isExist = newspaperRepository.existsById(id);
        newspaper.setId(id);
        if (isExist) return newspaperRepository.save(newspaper);
        throw new NewspaperNotFoundException("Newspaper Not Found");
    }

    @Override
    public Newspaper changeStatus(Long id) {
        Newspaper newspaper = findById(id);
        newspaper.setAvailable(!newspaper.isAvailable());

        return newspaperRepository.save(newspaper);
    }
}
