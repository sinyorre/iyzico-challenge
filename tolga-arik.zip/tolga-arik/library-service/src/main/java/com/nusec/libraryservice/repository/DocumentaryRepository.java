package com.nusec.libraryservice.repository;

import com.nusec.libraryservice.model.entity.Documentary;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DocumentaryRepository extends PagingAndSortingRepository<Documentary, Long> {
    Long countDocumentariesByAvailable(boolean available);

    Documentary findByName(String name);

}
