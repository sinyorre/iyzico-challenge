package com.nusec.libraryservice.repository;

import com.nusec.libraryservice.model.entity.Book;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface BookRepository extends PagingAndSortingRepository<Book, Long> {
    Long countBooksByAvailable(boolean available);

    Book findByName(String name);

}
