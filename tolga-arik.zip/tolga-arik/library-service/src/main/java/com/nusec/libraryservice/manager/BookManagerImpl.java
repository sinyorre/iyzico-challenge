package com.nusec.libraryservice.manager;

import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.dto.BookDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;
import com.nusec.libraryservice.model.entity.Book;
import com.nusec.libraryservice.service.IGenericService;
import com.nusec.libraryservice.utils.ModelMapperUtil;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class BookManagerImpl implements BookManager {

    private final ModelMapper modelMapper;

    private final IGenericService<Book> bookService;


    @Override
    public BookDTO saveBook(BookDTO bookDTO) {
        Book book = modelMapper.map(bookDTO, Book.class);
        Book savedBook = bookService.save(book);

        return modelMapper.map(savedBook, BookDTO.class);
    }

    @Override
    public BookDTO updateBook(Long id, BookDTO bookDTO) {
        Book book = modelMapper.map(bookDTO, Book.class);
        Book updatedBook = bookService.update(book, id);
        return modelMapper.map(updatedBook, BookDTO.class);
    }

    @Override
    public boolean deleteBook(Long id) {
        bookService.delete(id);
        return true;
    }

    @Override
    public BookDTO getBook(Long id) {
        Book book = bookService.findById(id);
        return modelMapper.map(book, BookDTO.class);
    }

    @Override
    public PagingResponseDTO<BookDTO> getBookList(Integer page) {
        PagingResponse<Book> bookPagingResponse = bookService.findAll(page);
        List<Book> bookList = bookPagingResponse.getData();
        List<BookDTO> bookDTOList = ModelMapperUtil.mapList(bookList, BookDTO.class);


        PagingResponseDTO<BookDTO> pagingResponseDTO = new PagingResponseDTO<>();
        pagingResponseDTO.setData(bookDTOList);
        pagingResponseDTO.setTotalElements(bookPagingResponse.getTotalElements());
        pagingResponseDTO.setTotalPages(bookPagingResponse.getTotalPages());
        return pagingResponseDTO;
    }

    @Override
    public BookDTO changeStatus(Long id) {
        Book book = bookService.changeStatus(id);
        return modelMapper.map(book, BookDTO.class);
    }

    @Override
    public Boolean getAvailableStatusByName(String name) {
        return bookService.getAvailableStatusByName(name);
    }

}
