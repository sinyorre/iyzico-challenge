package com.nusec.libraryservice.service;

import com.nusec.libraryservice.model.PagingResponse;

public interface IGenericService<T> {

    T save(T entity);

    PagingResponse<T> findAll(Integer page);

    T findById(Long id);

    void delete(Long id);

    Long countByAvailable(boolean available);

    Long count();

    Boolean getAvailableStatusByName(String name);

    T update(T entity, Long id);

    T changeStatus(Long id);
}
