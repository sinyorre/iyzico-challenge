package com.nusec.libraryservice.manager;

import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.dto.NewspaperDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;
import com.nusec.libraryservice.model.entity.Newspaper;
import com.nusec.libraryservice.service.IGenericService;
import com.nusec.libraryservice.utils.ModelMapperUtil;
import lombok.RequiredArgsConstructor;
import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
public class NewspaperManagerImpl implements NewspaperManager {

    private final ModelMapper modelMapper;

    private final IGenericService<Newspaper> newspaperIGenericService;


    @Override
    public NewspaperDTO saveNewspaper(NewspaperDTO newspaperDTO) {
        Newspaper newspaper = modelMapper.map(newspaperDTO, Newspaper.class);
        Newspaper savedNewspaper = newspaperIGenericService.save(newspaper);

        return modelMapper.map(savedNewspaper, NewspaperDTO.class);
    }

    @Override
    public NewspaperDTO updateNewspaper(Long id, NewspaperDTO newspaperDTO) {
        Newspaper newspaper = modelMapper.map(newspaperDTO, Newspaper.class);
        Newspaper updatedNewspaper = newspaperIGenericService.update(newspaper, id);
        return modelMapper.map(updatedNewspaper, NewspaperDTO.class);
    }

    @Override
    public boolean deleteNewspaper(Long id) {
        newspaperIGenericService.delete(id);
        return true;
    }

    @Override
    public NewspaperDTO getNewspaper(Long id) {
        Newspaper newspaper = newspaperIGenericService.findById(id);
        return modelMapper.map(newspaper, NewspaperDTO.class);
    }

    @Override
    public PagingResponseDTO<NewspaperDTO> getNewspaperList(Integer page) {
        PagingResponse<Newspaper> newspaperPagingResponse = newspaperIGenericService.findAll(page);
        List<Newspaper> newspaperList = newspaperPagingResponse.getData();
        List<NewspaperDTO> newspaperDTOList = ModelMapperUtil.mapList(newspaperList, NewspaperDTO.class);


        PagingResponseDTO<NewspaperDTO> pagingResponseDTO = new PagingResponseDTO<>();
        pagingResponseDTO.setData(newspaperDTOList);
        pagingResponseDTO.setTotalElements(newspaperPagingResponse.getTotalElements());
        pagingResponseDTO.setTotalPages(newspaperPagingResponse.getTotalPages());
        return pagingResponseDTO;
    }

    @Override
    public NewspaperDTO changeStatus(Long id) {
        Newspaper newspaper = newspaperIGenericService.changeStatus(id);
        return modelMapper.map(newspaper, NewspaperDTO.class);
    }

    @Override
    public Boolean getAvailableStatusByName(String name) {
        return newspaperIGenericService.getAvailableStatusByName(name);
    }

}
