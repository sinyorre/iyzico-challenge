package com.nusec.libraryservice.repository;

import com.nusec.libraryservice.model.entity.Newspaper;
import org.springframework.data.repository.PagingAndSortingRepository;

public interface NewspaperRepository extends PagingAndSortingRepository<Newspaper, Long> {
    Long countNewspapersByAvailable(boolean available);

    Newspaper findByName(String name);

}
