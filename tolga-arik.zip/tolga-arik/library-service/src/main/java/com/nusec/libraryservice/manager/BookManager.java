package com.nusec.libraryservice.manager;

import com.nusec.libraryservice.model.dto.BookDTO;
import com.nusec.libraryservice.model.dto.PagingResponseDTO;

public interface BookManager {

    BookDTO saveBook(BookDTO bookDTO);

    BookDTO updateBook(Long id, BookDTO bookDTO);

    boolean deleteBook(Long id);

    BookDTO getBook(Long id);

    PagingResponseDTO<BookDTO> getBookList(Integer page);

    BookDTO changeStatus(Long id);

    Boolean getAvailableStatusByName(String name);
}
