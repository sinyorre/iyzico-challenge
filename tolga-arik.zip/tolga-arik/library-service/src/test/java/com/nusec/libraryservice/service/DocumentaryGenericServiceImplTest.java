package com.nusec.libraryservice.service;

import com.nusec.libraryservice.exceptions.DocumentaryNotFoundException;
import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.entity.Documentary;
import com.nusec.libraryservice.repository.DocumentaryRepository;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class DocumentaryGenericServiceImplTest {
    @Mock
    private DocumentaryRepository documentaryRepository;
    @InjectMocks
    private DocumentaryGenericServiceImpl documentaryGenericService;

    @Test
    void save() {
        Documentary documentary = new Documentary();
        documentary.setId(1l);
        documentaryGenericService.save(documentary);
        verify(documentaryRepository, times(1)).save(documentary);

    }

    @Test
    void findAll() {
        Pageable pageable = Pageable.ofSize(10);
        PageImpl<Documentary> page = new PageImpl<Documentary>(Lists.newArrayList(new Documentary()), pageable, 10);
        when(documentaryRepository.findAll(any(Pageable.class))).thenReturn(page);
        PagingResponse<Documentary> all = documentaryGenericService.findAll(1);
        assertEquals(1, all.getData().size());
        assertEquals(10, all.getTotalElements());
        assertEquals(1, all.getTotalPages());
    }

    @Test
    void findById() {
        Documentary documentary = new Documentary();
        documentary.setId(1L);
        when(documentaryRepository.findById(1L)).thenReturn(Optional.of(documentary));
        Documentary returnedDocumentary = documentaryGenericService.findById(1L);
        assertEquals(1L, returnedDocumentary.getId());
        verify(documentaryRepository, times(1)).findById(1L);
    }


    @Test
    void findByIdShouldFail() {
        assertThrows(DocumentaryNotFoundException.class, () -> documentaryGenericService.findById(1L));
    }

    @Test
    void update() {
        Documentary documentary = new Documentary();
        documentary.setId(1L);
        when(documentaryRepository.existsById(anyLong())).thenReturn(true);
        documentaryGenericService.update(documentary, 1L);
        verify(documentaryRepository, times(1)).save(any());
    }

    @Test
    void updateShouldFail() {
        Documentary documentary = new Documentary();
        documentary.setId(1L);
        when(documentaryRepository.existsById(anyLong())).thenReturn(false);
        assertThrows(DocumentaryNotFoundException.class, () -> documentaryGenericService.update(documentary, 1L));
    }

    @Test
    void changeStatus() {
        Documentary documentary = new Documentary();
        when(documentaryRepository.findById(anyLong())).thenReturn(Optional.of(documentary));
        when(documentaryRepository.save(any())).thenReturn(documentary);
        Documentary updated = documentaryGenericService.changeStatus(1L);
        assertTrue(updated.isAvailable());
        verify(documentaryRepository, times(1)).findById(anyLong());
        verify(documentaryRepository, times(1)).save(any());
    }

    @Test
    void delete() {
        documentaryGenericService.delete(1L);
        verify(documentaryRepository, times(1)).deleteById(1L);
    }

    @Test
    void countByAvailable() {
        documentaryGenericService.countByAvailable(true);
        verify(documentaryRepository, times(1)).countDocumentariesByAvailable(true);
    }

    @Test
    void count() {
        documentaryGenericService.count();
        verify(documentaryRepository, times(1)).count();
    }

    @Test
    void getAvailableStatusByName() {
        Documentary documentary = new Documentary();
        documentary.setAvailable(true);
        when(documentaryRepository.findByName(anyString())).thenReturn(documentary);
        Boolean status = documentaryGenericService.getAvailableStatusByName("test");
        verify(documentaryRepository, times(1)).findByName(anyString());
        assertTrue(status);
    }
}