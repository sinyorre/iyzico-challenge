package com.nusec.libraryservice.service;

import com.nusec.libraryservice.exceptions.BookNotFoundException;
import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.entity.Book;
import com.nusec.libraryservice.repository.BookRepository;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class BookGenericServiceImplTest {
    @Mock
    private BookRepository bookRepository;
    @InjectMocks
    private BookGenericServiceImpl bookGenericService;

    @Test
    void save() {
        Book book = new Book();
        book.setId(1l);
        bookGenericService.save(book);
        verify(bookRepository, times(1)).save(book);

    }

    @Test
    void findAll() {
        Pageable pageable = Pageable.ofSize(10);
        PageImpl<Book> page = new PageImpl<Book>(Lists.newArrayList(new Book()), pageable, 10);
        when(bookRepository.findAll(any(Pageable.class))).thenReturn(page);
        PagingResponse<Book> all = bookGenericService.findAll(1);
        assertEquals(1, all.getData().size());
        assertEquals(10, all.getTotalElements());
        assertEquals(1, all.getTotalPages());
    }

    @Test
    void findById() {
        Book book = new Book();
        book.setId(1L);
        when(bookRepository.findById(1L)).thenReturn(Optional.of(book));
        Book returnedBook = bookGenericService.findById(1L);
        assertEquals(1L, returnedBook.getId());
        verify(bookRepository, times(1)).findById(1L);
    }


    @Test
    void findByIdShouldFail() {
        assertThrows(BookNotFoundException.class, () -> bookGenericService.findById(1L));
    }

    @Test
    void update() {
        Book book = new Book();
        book.setId(1L);
        when(bookRepository.existsById(anyLong())).thenReturn(true);
        bookGenericService.update(book, 1L);
        verify(bookRepository, times(1)).save(any());
    }

    @Test
    void updateShouldFail() {
        Book book = new Book();
        book.setId(1L);
        when(bookRepository.existsById(anyLong())).thenReturn(false);
        assertThrows(BookNotFoundException.class, () -> bookGenericService.update(book, 1L));
    }

    @Test
    void changeStatus() {
        Book book = new Book();
        when(bookRepository.findById(anyLong())).thenReturn(Optional.of(book));
        when(bookRepository.save(any())).thenReturn(book);
        Book updated = bookGenericService.changeStatus(1L);
        assertTrue(updated.isAvailable());
        verify(bookRepository, times(1)).findById(anyLong());
        verify(bookRepository, times(1)).save(any());
    }

    @Test
    void delete() {
        bookGenericService.delete(1L);
        verify(bookRepository, times(1)).deleteById(1L);
    }

    @Test
    void countByAvailable() {
        bookGenericService.countByAvailable(true);
        verify(bookRepository, times(1)).countBooksByAvailable(true);
    }

    @Test
    void count() {
        bookGenericService.count();
        verify(bookRepository, times(1)).count();
    }

    @Test
    void getAvailableStatusByName() {
        Book book = new Book();
        book.setAvailable(true);
        when(bookRepository.findByName(anyString())).thenReturn(book);
        Boolean status = bookGenericService.getAvailableStatusByName("test");
        verify(bookRepository, times(1)).findByName(anyString());
        assertTrue(status);
    }
}