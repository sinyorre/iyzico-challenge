package com.nusec.libraryservice.service;

import com.nusec.libraryservice.exceptions.NewspaperNotFoundException;
import com.nusec.libraryservice.model.PagingResponse;
import com.nusec.libraryservice.model.entity.Newspaper;
import com.nusec.libraryservice.repository.NewspaperRepository;
import org.assertj.core.util.Lists;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NewspaperGenericServiceImplTest {
    @Mock
    private NewspaperRepository newspaperRepository;
    @InjectMocks
    private NewspaperGenericServiceImpl newspaperGenericService;

    @Test
    void save() {
        Newspaper newspaper = new Newspaper();
        newspaper.setId(1l);
        newspaperGenericService.save(newspaper);
        verify(newspaperRepository, times(1)).save(newspaper);

    }

    @Test
    void findAll() {
        Pageable pageable = Pageable.ofSize(10);
        PageImpl<Newspaper> page = new PageImpl<Newspaper>(Lists.newArrayList(new Newspaper()), pageable, 10);
        when(newspaperRepository.findAll(any(Pageable.class))).thenReturn(page);
        PagingResponse<Newspaper> all = newspaperGenericService.findAll(1);
        assertEquals(1, all.getData().size());
        assertEquals(10, all.getTotalElements());
        assertEquals(1, all.getTotalPages());
    }

    @Test
    void findById() {
        Newspaper newspaper = new Newspaper();
        newspaper.setId(1L);
        when(newspaperRepository.findById(1L)).thenReturn(Optional.of(newspaper));
        Newspaper returnedNewspaper = newspaperGenericService.findById(1L);
        assertEquals(1L, returnedNewspaper.getId());
        verify(newspaperRepository, times(1)).findById(1L);
    }


    @Test
    void findByIdShouldFail() {
        assertThrows(NewspaperNotFoundException.class, () -> newspaperGenericService.findById(1L));
    }

    @Test
    void update() {
        Newspaper newspaper = new Newspaper();
        newspaper.setId(1L);
        when(newspaperRepository.existsById(anyLong())).thenReturn(true);
        newspaperGenericService.update(newspaper, 1L);
        verify(newspaperRepository, times(1)).save(any());
    }

    @Test
    void updateShouldFail() {
        Newspaper newspaper = new Newspaper();
        newspaper.setId(1L);
        when(newspaperRepository.existsById(anyLong())).thenReturn(false);
        assertThrows(NewspaperNotFoundException.class, () -> newspaperGenericService.update(newspaper, 1L));
    }

    @Test
    void changeStatus() {
        Newspaper newspaper = new Newspaper();
        when(newspaperRepository.findById(anyLong())).thenReturn(Optional.of(newspaper));
        when(newspaperRepository.save(any())).thenReturn(newspaper);
        Newspaper updated = newspaperGenericService.changeStatus(1L);
        assertTrue(updated.isAvailable());
        verify(newspaperRepository, times(1)).findById(anyLong());
        verify(newspaperRepository, times(1)).save(any());
    }

    @Test
    void delete() {
        newspaperGenericService.delete(1L);
        verify(newspaperRepository, times(1)).deleteById(1L);
    }

    @Test
    void countByAvailable() {
        newspaperGenericService.countByAvailable(true);
        verify(newspaperRepository, times(1)).countNewspapersByAvailable(true);
    }

    @Test
    void count() {
        newspaperGenericService.count();
        verify(newspaperRepository, times(1)).count();
    }

    @Test
    void getAvailableStatusByName() {
        Newspaper newspaper = new Newspaper();
        newspaper.setAvailable(true);
        when(newspaperRepository.findByName(anyString())).thenReturn(newspaper);
        Boolean status = newspaperGenericService.getAvailableStatusByName("test");
        verify(newspaperRepository, times(1)).findByName(anyString());
        assertTrue(status);
    }
}